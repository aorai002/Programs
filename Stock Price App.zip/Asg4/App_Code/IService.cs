﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

// NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService" in both code and config file together.
[ServiceContract]
public interface IStockPrice
{

	[OperationContract]
    GraphData[] GetStockListByDate(DateTime firstDate, DateTime secondDate);

[OperationContract]
   GraphData[] GetMovingAverage(DateTime firstDate, DateTime secondDate, int n);

	// TODO: Add your service operations here
}

// Use a data contract as illustrated in the sample below to add composite types to service operations.
[DataContract]
public class DailyPrices
{
    public DailyPrices(DateTime date, double open, double high, double low, double close, double volume, double adj_volume)
    {
        Date = date;
        Open = open;
        High = high;
        Low = low;
        Close = close;
        Volume = volume;
        Adj_volume = adj_volume;
     
    }


	[DataMember]
	public DateTime Date {set; get;}
    [DataMember]
	public double Open {set; get;}
    [DataMember]
    public double High { set; get; }
    [DataMember]
    public double Low { set; get; }
    [DataMember]
    public double Close { set; get; }
    [DataMember]
    public double Volume { set; get; }
    [DataMember]
    public double Adj_volume { set; get; }

   }

[DataContract]
public class GraphData
{
    public GraphData(DateTime date, double value)
    {
        Date = date;
        Value = value;
        Count = 0;
   
    }

    [DataMember]
    public DateTime Date { set; get; }
    [DataMember]
    public Double Value { set; get; }
    [DataMember]
    public Double Count { set; get; }

}

//[DataContract]
//public class XmlReader
//{
//    public static bool Read(List<DailyPrices> dailyList, string path)
//    {
//        try
//        {
//            System.Xml.XmlTextReader reader = new System.Xml.XmlTextReader(path);
//            reader.Read();
//            while (reader.Read())
//            {
//                reader.MoveToContent();
//                if (reader.NodeType == System.Xml.XmlNodeType.Element)
//                {
//                    if (reader.Name == "Row")
//                    {
//                        DailyPrices S = readDailyPrices(reader);
//                        dailyList.Add(S);
//                    }
//                }
//            }
//            dailyList.Reverse();
//            return true;
//        }
//        catch (System.IO.FileNotFoundException)
//        {
//            return false;
//        }
//    }



//    static DailyPrices readDailyPrices(System.Xml.XmlTextReader reader)
//    {
//        // Excel dates are encoded as integers, where 1/1/1900 = 1. There is a bug
//        // in their date calculations because they consider 1900 to be a leap year. This
//        // bug was never corrected because it first appeared in Lotus 1-2-3 and Microsoft
//        // wanted the two products to be compatible.

//        int offset = 2;
//        int excelDays = Convert.ToInt32(nextValue(reader)) - offset;
//        DateTime start = new DateTime(1900, 1, 1);
//        TimeSpan ts = new TimeSpan(excelDays, 0, 0, 0);
//        DateTime D = start.Add(ts);

//        double open = Convert.ToDouble(nextValue(reader));
//        double high = Convert.ToDouble(nextValue(reader));
//        double low = Convert.ToDouble(nextValue(reader));
//        double close = Convert.ToDouble(nextValue(reader));
//        double volume = Convert.ToDouble(nextValue(reader));
//        double adj = Convert.ToDouble(nextValue(reader));

//        DailyPrices S = new DailyPrices(D, open, high, low, close, volume, adj);
//        return S;
//    }

//    static string nextValue(System.Xml.XmlTextReader reader)
//    {
//        while (reader.Read())
//        {
//            if (reader.NodeType == System.Xml.XmlNodeType.Text)
//                return reader.Value;
//        }
//        return null;
//    }
  
//}