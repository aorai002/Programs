﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

// NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service" in code, svc and config file together.
public class StockPrice : IStockPrice
{
    List<DailyPrices> prices = new List<DailyPrices>();
    string path = "http://users.cis.fiu.edu/~irvinek/cop4814/data/ulti.xml";
    /*http://users.cis.fiu.edu/~irvinek/cop4814/data/ulti.xml
    http://cis.fiu.edu/~irvinek/cop4814/examples/ulti.xml*/

    StockPrice()
    {
        Read(prices, path);
    }

    public GraphData[] GetStockListByDate(DateTime fDate, DateTime sDate)
    {
        List<GraphData> getRange = new List<GraphData>();

        foreach (DailyPrices d in prices)
        {
            if (d.Date >= fDate & d.Date <= sDate)
                getRange.Add(new GraphData(d.Date, d.Close));
        }

        return getRange.ToArray();
    }

    public GraphData[] GetMovingAverage(DateTime fDate, DateTime sDate, int days)
    {
        List<GraphData> getRange = new List<GraphData>();
        int startIndex = 0; 
        int endIndex = 0;  

        for (int i = 0; i < prices.Count; i++)
        {
            if (!(fDate <= prices[i].Date))
            {
                startIndex = i + 1;
            }
            if (!(sDate <= prices[i].Date))
            {
                if (days == 1)
                    endIndex = i + 1;
                else
                    endIndex = i + days;
            }
        }

        double total = 0;
        double average = 0;

        for (int i = startIndex; i < endIndex+1 - days; i++)
        {
            total = 0;
            average = 0;

            for (int j = i; j < i + days && j < endIndex + 1; j++)
            {
                total += prices[j].Close;
            }

            average = total / days;

            getRange.Add(new GraphData(prices[i].Date, average));
        }

        return getRange.ToArray();
    }

    /*XML Reader Method Start*/
    public static bool Read(List<DailyPrices> dailyList, string path)
    {
        try
        {
            System.Xml.XmlTextReader reader = new System.Xml.XmlTextReader(path);
            reader.Read();
            while (reader.Read())
            {
                reader.MoveToContent();
                if (reader.NodeType == System.Xml.XmlNodeType.Element)
                {
                    if (reader.Name == "Row")
                    {
                        DailyPrices S = readDailyPrices(reader);
                        dailyList.Add(S);
                    }
                }
            }
            dailyList.Reverse();
            return true;
        }
        catch (System.IO.FileNotFoundException)
        {
            return false;
        }
    }



    static DailyPrices readDailyPrices(System.Xml.XmlTextReader reader)
    {
        // Excel dates are encoded as integers, where 1/1/1900 = 1. There is a bug
        // in their date calculations because they consider 1900 to be a leap year. This
        // bug was never corrected because it first appeared in Lotus 1-2-3 and Microsoft
        // wanted the two products to be compatible.

        int offset = 2;
        int excelDays = Convert.ToInt32(nextValue(reader)) - offset;
        DateTime start = new DateTime(1900, 1, 1);
        TimeSpan ts = new TimeSpan(excelDays, 0, 0, 0);
        DateTime D = start.Add(ts);

        double open = Convert.ToDouble(nextValue(reader));
        double high = Convert.ToDouble(nextValue(reader));
        double low = Convert.ToDouble(nextValue(reader));
        double close = Convert.ToDouble(nextValue(reader));
        double volume = Convert.ToDouble(nextValue(reader));
        double adj = Convert.ToDouble(nextValue(reader));

        DailyPrices S = new DailyPrices(D, open, high, low, close, volume, adj);
        return S;
    }

    static string nextValue(System.Xml.XmlTextReader reader)
    {
        while (reader.Read())
        {
            if (reader.NodeType == System.Xml.XmlNodeType.Text)
                return reader.Value;
        }
        return null;
    }
}

    
    
    

