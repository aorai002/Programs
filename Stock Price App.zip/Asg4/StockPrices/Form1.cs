﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace StockPrices
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (txtSMAdays.Text.Equals(""))
                txtSMAdays.AppendText("1");

            stockChart.Legends.Clear();
            stockChart.Series.Clear();
            DateTime first = date1.Value;
            DateTime second = date2.Value;
            localhost.StockPriceClient client = new localhost.StockPriceClient();
            localhost.GraphData[] list = client.GetStockListByDate(first, second);
            List<ChartData> chartD = new List<ChartData>();

            foreach (localhost.GraphData d in list)
            {
                chartD.Add(new ChartData(d.Date, d.Value));
            }
           
            Series S = new Series("Closing Prices");
            S.Color = Color.Blue;
            S.XValueMember = "xVal";
            S.YValueMembers = "yVal";
            S.ChartType = SeriesChartType.Line;
            S.XValueType = ChartValueType.Date;
            S.YValueType = ChartValueType.Double;
            stockChart.Series.Add(S);
            stockChart.DataSource = chartD.ToArray();
            stockChart.ChartAreas[0].AxisY.Minimum = getMinValue(chartD) - 2;
            stockChart.ChartAreas[0].AxisY.Maximum = getMaxValue(chartD) + 2;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            bool containsLetter = false;
            string sma = txtSMAdays.Text.Trim();
            lblError.Text = "";

            for (int i = 0; i < sma.Length; i++)
            {
                if (!char.IsNumber(sma[i]))
                {
                    containsLetter = true;
                }
            }

            if (containsLetter)
            {
                string error = " is an invalid SMA day";
                lblError.ForeColor = Color.Red;
                lblError.Text += "'" + txtSMAdays.Text + "'" + error;
                txtSMAdays.Clear();
            } 

            if (txtSMAdays.Text.Equals(""))
                txtSMAdays.AppendText("1");

            stockChart.Legends.Clear();
            stockChart.Series.Clear();
            int days = int.Parse(txtSMAdays.Text);
            DateTime first = date1.Value;
            DateTime second = date2.Value;
            localhost.StockPriceClient client = new localhost.StockPriceClient();
            localhost.GraphData[] list2 = client.GetMovingAverage(first, second, days);
            List<ChartData> chartD = new List<ChartData>();

            foreach (localhost.GraphData d in list2)
            {
                chartD.Add(new ChartData(d.Date, d.Value));
            }

            Series S = new Series("SMA   Closing");
            S.Color = Color.Purple;
            S.XValueMember = "xVal";
            S.YValueMembers = "yVal";
            S.ChartType = SeriesChartType.Line;
            S.XValueType = ChartValueType.Date;
            S.YValueType = ChartValueType.Double;
            stockChart.Series.Add(S);
            stockChart.DataSource = chartD.ToArray();
            stockChart.ChartAreas[0].AxisY.LabelStyle.Format = "#.#0";
            stockChart.ChartAreas[0].AxisY.Minimum = getMinValue(chartD) - 2;
            stockChart.ChartAreas[0].AxisY.Maximum = getMaxValue(chartD) + 2;
        }

        private double getMinValue(List<ChartData> cd)
        {
            double min = Double.MaxValue;

            foreach (ChartData k in cd)
            {
                if (k.yVal < min)
                    min = k.yVal;
            }

            return min;
        }

        private double getMaxValue(List<ChartData> cd)
        {
            double max = 0;

            foreach (ChartData k in cd)
            {
                if (k.yVal > max)
                    max = k.yVal;
            }

            return max;
        }
    }
}

public class ChartData
{
    public DateTime xVal { get; set; }
    public double yVal { get; set; }

    public ChartData(DateTime x, double y)
    {
        xVal = x;
        yVal = y;
    }
}