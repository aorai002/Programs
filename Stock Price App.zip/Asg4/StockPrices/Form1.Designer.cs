﻿namespace StockPrices
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            this.date1 = new System.Windows.Forms.DateTimePicker();
            this.date2 = new System.Windows.Forms.DateTimePicker();
            this.stockChart = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.btnClosePrice = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnSMA = new System.Windows.Forms.Button();
            this.txtSMAdays = new System.Windows.Forms.TextBox();
            this.lblDays = new System.Windows.Forms.Label();
            this.lblError = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.stockChart)).BeginInit();
            this.SuspendLayout();
            // 
            // date1
            // 
            this.date1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.date1.Location = new System.Drawing.Point(149, 27);
            this.date1.Name = "date1";
            this.date1.Size = new System.Drawing.Size(112, 20);
            this.date1.TabIndex = 1;
            this.date1.Value = new System.DateTime(2010, 1, 1, 21, 37, 0, 0);
            // 
            // date2
            // 
            this.date2.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.date2.Location = new System.Drawing.Point(304, 27);
            this.date2.Name = "date2";
            this.date2.Size = new System.Drawing.Size(112, 20);
            this.date2.TabIndex = 2;
            this.date2.Value = new System.DateTime(2011, 1, 1, 21, 37, 0, 0);
            // 
            // stockChart
            // 
            this.stockChart.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            chartArea1.Name = "ChartArea1";
            this.stockChart.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.stockChart.Legends.Add(legend1);
            this.stockChart.Location = new System.Drawing.Point(12, 77);
            this.stockChart.Name = "stockChart";
            this.stockChart.Size = new System.Drawing.Size(773, 312);
            this.stockChart.TabIndex = 4;
            this.stockChart.Text = "chart1";
            // 
            // btnClosePrice
            // 
            this.btnClosePrice.Location = new System.Drawing.Point(12, 25);
            this.btnClosePrice.Name = "btnClosePrice";
            this.btnClosePrice.Size = new System.Drawing.Size(83, 23);
            this.btnClosePrice.TabIndex = 5;
            this.btnClosePrice.Text = "Closing Prices";
            this.btnClosePrice.UseVisualStyleBackColor = true;
            this.btnClosePrice.Click += new System.EventHandler(this.button2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(107, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(33, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "From:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(274, 30);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(23, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "To:";
            // 
            // btnSMA
            // 
            this.btnSMA.Location = new System.Drawing.Point(505, 24);
            this.btnSMA.Name = "btnSMA";
            this.btnSMA.Size = new System.Drawing.Size(75, 23);
            this.btnSMA.TabIndex = 8;
            this.btnSMA.Text = "SMA";
            this.btnSMA.UseVisualStyleBackColor = true;
            this.btnSMA.Click += new System.EventHandler(this.button3_Click);
            // 
            // txtSMAdays
            // 
            this.txtSMAdays.Location = new System.Drawing.Point(586, 26);
            this.txtSMAdays.Name = "txtSMAdays";
            this.txtSMAdays.Size = new System.Drawing.Size(59, 20);
            this.txtSMAdays.TabIndex = 9;
            // 
            // lblDays
            // 
            this.lblDays.AutoSize = true;
            this.lblDays.Location = new System.Drawing.Point(652, 29);
            this.lblDays.Name = "lblDays";
            this.lblDays.Size = new System.Drawing.Size(37, 13);
            this.lblDays.TabIndex = 10;
            this.lblDays.Text = "Day(s)";
            // 
            // lblError
            // 
            this.lblError.AutoSize = true;
            this.lblError.Location = new System.Drawing.Point(505, 5);
            this.lblError.Name = "lblError";
            this.lblError.Size = new System.Drawing.Size(0, 13);
            this.lblError.TabIndex = 11;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(797, 401);
            this.Controls.Add(this.lblError);
            this.Controls.Add(this.lblDays);
            this.Controls.Add(this.txtSMAdays);
            this.Controls.Add(this.btnSMA);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnClosePrice);
            this.Controls.Add(this.stockChart);
            this.Controls.Add(this.date2);
            this.Controls.Add(this.date1);
            this.Name = "Form1";
            this.Text = "Stock Service Consumer";
            ((System.ComponentModel.ISupportInitialize)(this.stockChart)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DateTimePicker date1;
        private System.Windows.Forms.DateTimePicker date2;
        private System.Windows.Forms.DataVisualization.Charting.Chart stockChart;
        private System.Windows.Forms.Button btnClosePrice;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnSMA;
        private System.Windows.Forms.TextBox txtSMAdays;
        private System.Windows.Forms.Label lblDays;
        private System.Windows.Forms.Label lblError;
    }
}

