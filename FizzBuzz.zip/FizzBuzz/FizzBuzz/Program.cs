﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace FizzBuzz
{
    static class Program
    {
        static void Main()
        {
            Application.Run(new FizzBuzz());
        }
    }
}
