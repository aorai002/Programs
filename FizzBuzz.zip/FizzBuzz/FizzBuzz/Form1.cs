﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;



/*
 * This program was done in a very short time. Please excuse the lack of commentation. I always consider the possible next programmer and leave diligent notations for my logic
 * This generates a list of random numbers of up to 100 and takes the users inputs after validation to create the fizzbuzz app. I hope you enjoy it.
 */
namespace FizzBuzz
{
    public partial class FizzBuzz : Form
    {
        int[] numberList = new int[10];
        
        public FizzBuzz()
        {
            InitializeComponent();
            Random r = new Random();
            for (int x = 0; x < 10; x++)
            {
                int temp = r.Next(0, 100); //randomly finds a random number between -100, 100
                listb.Items.Add(temp); //adds random number to display on list
                numberList[x] = temp;
            }
        }

        private void btn_Close_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_Clear_Click(object sender, EventArgs e)
        {
            txtbx_Higher.Text = "";
            txtbox_Lower.Text = "";
            lbl_result.Text = "";
            lbl_performance.Text = "";
            listb.ClearSelected();
        }

        private void FizzBuzz_Load(object sender, EventArgs e)
        {
            txtbx_Higher.Text = "";
            txtbox_Lower.Text = "";
        }

        private void txtbox_Lower_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if (!Char.IsDigit(ch))
            {
                e.Handled = true;
                MessageBox.Show("Must be an Integer", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtbox_Lower.Text = "";
            }
        }

        private void txtbx_Higher_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            
            if (!Char.IsDigit(ch))
            {
                e.Handled = true;
                MessageBox.Show("Must be an Integer", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtbx_Higher.Text = "";
            }
        }

        private void btn_Calculate_Click(object sender, EventArgs e)
        {
            lbl_performance.Text = "";
            if (txtbox_Lower.Text == "" || txtbx_Higher.Text == "")
            {
                MessageBox.Show("Please fill all input fields", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (listb.SelectedItem == null)
            {
                MessageBox.Show("Please select a number for the list", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            int l = Convert.ToInt32(txtbox_Lower.Text);
            int h = Convert.ToInt32(txtbx_Higher.Text);

            int i = listb.SelectedIndex;
            int dividedBy = numberList[i];
            String answer = "";
            String status = "";

            //lbl_result.Text = l.ToString() + " " + h.ToString() + " " + dividedBy.ToString();

                //int.Parse(listb.SelectedItem.ToString());
            
            if( l > h )
            {
                MessageBox.Show("Lower # cannot be higher than the Higher #", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtbox_Lower.Text = "";
                txtbx_Higher.Text = "";
                return;
            }

            if (dividedBy % l == 0)
            {
                lbl_result.Text = "Fizz";
                answer = "Fizz";
                lbl_performance.Text = "Divided " + dividedBy.ToString() + " by: " + l.ToString() + System.Environment.NewLine;
                status = "Divided " + dividedBy.ToString() + " by: " + l.ToString() + System.Environment.NewLine;
            }
            if (dividedBy % h == 0)
            {
                lbl_result.Text = answer + "Buzz";
                lbl_performance.Text = status + "Divided " + dividedBy.ToString() + " by: " + h.ToString();
            }
            if ((dividedBy % l != 0) && (dividedBy % h != 0))
            {
                lbl_result.Text = dividedBy.ToString() + " - N/A";
            }
        }
    }
}
